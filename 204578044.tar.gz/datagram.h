#ifndef DATAGRAM
#define DATAGRAM



struct Datagram
{
	char* data = NULL;
	int length = 0;
};

#endif